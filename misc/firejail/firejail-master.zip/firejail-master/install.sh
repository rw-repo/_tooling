#!/bin/sh
# This file is part of Firejail project
# Copyright (C) 2014-2022 Firejail Authors
# License GPL v2

echo "installing..."
