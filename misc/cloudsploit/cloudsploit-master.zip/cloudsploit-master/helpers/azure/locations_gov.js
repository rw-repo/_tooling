// Source: https://azure.microsoft.com/en-us/global-infrastructure/services/

var locations = [
    'usgovvirginia',
    'usgoviowa',
    'usgovtexas',
    'usgovarizona',
    'usdodeast',
    'usdodcentral'
];

module.exports = {
    all: locations
};
