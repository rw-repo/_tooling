var regions = [
    'us-gov-ashburn-1',
    'us-gov-phoenix-1'
];

module.exports = {
    all: regions,
    vcn: regions
};
