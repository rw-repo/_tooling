package version

var (
	// Version holds the version name.
	Version = "dev"
	// Commit holds the version build commit.
	Commit = "I don't remember exactly"
	// Date holds the version build date.
	Date = "I don't remember exactly"
)
