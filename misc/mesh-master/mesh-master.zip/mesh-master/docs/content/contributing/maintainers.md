---
title: "Traefik Mesh Maintainers"
description: "In this article, you can find the list of Traefik Mesh maintainers."
---

# Maintainers

- Daniel Tomcej [@dtomcej](https://github.com/dtomcej)
- Manuel Zapf [@SantoDE](https://github.com/SantoDE)
- Michaël Matur [@mmatur](https://github.com/mmatur)
- Landry Benguigui [@LandryBe](https://github.com/LandryBe)
- Harold Ozouf [@jspdown](https://github.com/jspdown)
- Julien Levesy [@jlevesy](https://github.com/jlevesy)
- Brendan Le Glaunec [@Ullaakut](https://github.com/Ullaakut)
- Kevin Pollet [@kevinpollet](https://github.com/kevinpollet)
