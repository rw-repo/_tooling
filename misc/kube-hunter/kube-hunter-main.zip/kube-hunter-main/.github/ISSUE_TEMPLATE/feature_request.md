---
name: Feature Request
about: I have a suggestion (and might want to implement myself)
labels: enhancement
---

## What would you like to be added

<!---
  Please describe the idea you have and the problem you are trying to solve.
-->

## Why is this needed

<!---
  Please explain why is this feature needed and how it improves the project.
-->
