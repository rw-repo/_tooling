---
name: Bug report
about: I would like to report a bug within the project
labels: bug
---

### What happened

<!---
  Please explain in detail steps you took and what happened.
-->

### Expected behavior

<!---
  What should happen, ideally?
-->
