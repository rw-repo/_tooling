# flake8: noqa: E402
from kube_hunter.modules.report.factory import get_reporter, get_dispatcher
