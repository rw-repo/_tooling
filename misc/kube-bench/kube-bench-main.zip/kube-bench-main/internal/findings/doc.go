/*
Package findings handles sending findings to Security Hub.
*/
package findings
